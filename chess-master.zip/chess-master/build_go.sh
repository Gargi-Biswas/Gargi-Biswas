cd ~/public_html/chess/go
go install server
cp bin/server ~/public_html/cgi-bin/chess_go_ai.cgi
cd -
