Chess by Devin Gray
===============================================================
http://www.devingray.com/chess

This is an evolving chess application written by Devin Gray.  The languages used in this application are: PHP, HTML, and Javascript on the front-end, which will invoke a CGI program written in C and/or Go on the back-end.  I will experiment with many types of game modes and AI algorithms.  My goal is to build an AI that can beat me consistently in a head to head match, or at the very least a fun game of chess!
